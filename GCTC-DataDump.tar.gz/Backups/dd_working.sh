#!/bin/bash
red=`tput setaf 1`
green=`tput setaf 2`
reset=`tput sgr0`

#lists all drives
lsblk
echo "please enter the disk which you wish to backup."
#loads var disk from entered text.
read disk

echo "Please enter the students first letter of their first name, and their last name."
echo "For example Caleb Orvis would become corvis."
#loads var diskName from entered text.
read diskName
mkdir ~/Desktop/Backups/Drives/$diskName
clear
if sudo dd if=/dev/$disk of=~/Desktop/Backups/Drives/$diskName/$diskName.iso status=progress;
then	
	sudo chmod 775 ~/Desktop/Backups/Drives/$diskName/$diskName.iso
	sudo mount ~/Desktop/Backups/Drives/$diskName/$diskName.iso /mnt | tail -0
	echo " "
	echo " "
	echo " "
	echo " "
	echo " "
	clear
	echo "-----------------------------"
    echo "-----------------------------"
    echo " "
	echo "${green}It worked!${reset}"
	echo " "
    echo "-----------------------------"
    echo "-----------------------------"
    echo " "
    echo "${green}Backup image contents are stored in your Desktop inside of a folder with the owners name. ${reset}"
    echo " "
    


    echo "-----------------------------"
    echo "-----------------------------"
    echo " "
    echo "${green}Backup image conntains ${reset}"
	tree /mnt | tail -2 

	sudo touch ~/Desktop/Backups/Drives/$diskName/$diskName.log |  date >> ~/Desktop/Backups/Drives/$diskName/$diskName.log 
	tree /mnt | tail -2 >>  ~/Desktop/Backups/Drives/$diskName/$diskName.log 
	
	sudo umount /mnt

	echo "${green}Thank you for using this script, press enter to exit."
	read end
	
fi
	clear
	echo "${red}-----------------------------"
    echo "-----------------------------"
    echo "Error script failed. Ensure you typed in a valid name, and selected the proper device to backup."
    echo "-----------------------------"
    echo "-----------------------------${reset}"
 #   echo "Zipping File, please wait!"
   

#pv zip ~/Desktop/Backups/Drives/$diskName *


    echo " "
    echo ""
echo "${green}Press enter to exit."
read end