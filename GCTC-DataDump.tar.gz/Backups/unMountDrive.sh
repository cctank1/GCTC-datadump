#!/bin/bash
echo "Drive being unmounted!"
sudo umount ~/Desktop/Backups/Mounted

echo "Drive unmounted, please press enter to exit."
read end