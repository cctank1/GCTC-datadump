#!/bin/bash


red=`tput setaf 1`
green=`tput setaf 2`
reset=`tput sgr0`



echo "Please enter the students first letter of their first name, and their last name."
echo "For example Caleb Orvis would become corvis."

read diskName

if sudo mount ~/Desktop/Backups/Drives/$diskName/$diskName.iso ~/Desktop/Backups/Mounted | tail -0

then 
clear
echo "${green} "
tree  ~/Desktop/Backups/Mounted 

echo ""
echo ""

echo "Drive Mounted"
fi
echo "${red}Please press enter to exit."
read end